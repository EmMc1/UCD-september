// see https://medium.com/@rameshsainom/javascripts-dom-mutation-and-promises-advance-javascript-95da5258297c for more details on updating the DOM and promises
//

class DataTable {
    // properties
    #dataUrl;
    #title;
    #data;
    #contentContainer;

    constructor(dataUrl, title) {
        this.#dataUrl = dataUrl;
        this.#title = title;
        this.#contentContainer = document.getElementById("content");
        this.loadProductData(); // load data using fetch and build the table
    }

    getContentContainer() {
        return this.#contentContainer;
    }

    render(){
        const capitaliseFirstLetter = (string) => {
            return string.charAt(0).toUpperCase() + string.slice(1);
        }
        const tableData = this.#data;
        // get property names from first object in array
        const propNames = Object.getOwnPropertyNames(tableData[0]);
        console.log(propNames);
        let outputHtml = `<div class="table-container">
            <h2>${this.#title}</h2>
                <table class="blueTable">
                    <thead>
                        <tr>`;
        propNames.forEach((prop) => {
            outputHtml += `<th>${capitaliseFirstLetter(prop)}</th>`;
        });                
        outputHtml += `</tr></thead><tbody>`;

        for (let i in tableData) {
            outputHtml += '<tr>';
            propNames.forEach((prop) => {
                outputHtml += `<td>${tableData[i][prop]}</td>`;
            });                
            outputHtml += '</tr>';
        }
        outputHtml += `     </tbody>
            </table>
        </div>`;

        this.#contentContainer.innerHTML += outputHtml;
    }

    async loadProductData(){ 
        try{
            //after this line, our function will wait for the `fetch()` call to be settled
            //the `fetch()` call will either return a Response or throw an error 
            const response = await fetch(this.#dataUrl);
            if(!response.ok){
                throw new Error(`HTTPerror:${response.status}`);
            }
            //after this line, our function will wait for the`response.json()`call to be settled
            //the`response.json()`call will either return the parsed JSON object or throw an error 
            this.#data=await response.json();
            console.log(this.#data[0].name);
            this.render(); // update the DOM
        } catch(error){
            console.error(`Could not get product data:${error}`);
        }

    }

}

function init() {
    //holidays table
    let holidaysDataTable = null;
    try {
        // build table using an instance of DataTable class
        holidaysDataTable = new DataTable("https://date.nager.at/api/v3/PublicHolidays/2024/IE", "List of Public Holidays in Ireland for 2024");
    } catch(err) {
        console.error(err);
        holidaysDataTable.getContentContainer().innerHTML += '<h2>Error</h2><p>No product data to display.</p><p>' + err + '</p>';
    }
        //products table
    let productsDataTable = null;
    try {
        // build table using an instance of DataTable class
        productsDataTable = new DataTable("https://mdn.github.io/learning-area/javascript/apis/fetching-data/can-store/products.json", "List of Products");
    } catch(err) {
        console.error(err);
        productsDataTable.getContentContainer().innerHTML += '<h2>Error</h2><p>No product data to display.</p><p>' + err + '</p>';
    }
}

window.addEventListener("load", (event => {
    init();
}));

